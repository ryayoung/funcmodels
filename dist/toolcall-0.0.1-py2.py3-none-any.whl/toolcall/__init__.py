from toolcall.openai_function import (
    OpenaiFunction,
    openai_function,
    OpenaiFunctionGroup,
    openai_function_group,
)
