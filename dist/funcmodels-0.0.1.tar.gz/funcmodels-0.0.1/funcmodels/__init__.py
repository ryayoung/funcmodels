from funcmodels.funcmodel import funcmodel
from funcmodels.openai_function import openai_function
